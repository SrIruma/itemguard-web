package dev.mugi.itemguard.addon;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * The contract between ItemGuard and a bridge to another plugin.
 *
 * <p>Implement this, put the class in {@code META-INF/services/} under its own
 * name, and ItemGuard will find it with the service loader. Nothing else is needed:
 * no registration, no dependency on ItemGuard's own classes, no code in the core
 * naming yours.
 *
 * <h2>What this is for</h2>
 *
 * <p>ItemGuard knows about items, containers, drops and blocks. It does not know
 * that a SmartSpawner spawner is a block with stored data behind it, that another
 * plugin may consider it "theirs", or that destroying it needs a call rather than a
 * broken block. A bridge fills that gap, and nothing else.
 *
 * <h2>Everything is a default method</h2>
 *
 * <p>A bridge that only answers "is this block mine?" implements one method. A bridge
 * that wants more implements the rest. The defaults are deliberately conservative
 * rather than convenient: {@link #ownsBlock} returning false means ItemGuard will not
 * treat your blocks as protected-by-anyone-else, which is the safe answer for a bridge
 * that is not yet ready.
 *
 * <h2>The rules a bridge must follow</h2>
 *
 * <ul>
 *   <li><b>Never throw.</b> Every call is wrapped. An exception from your code is
 *       caught, reported as your bridge being unavailable, and otherwise ignored — but
 *       it will have already cost a block event, so do not rely on that.</li>
 *   <li><b>No compile-time dependency on the bridged plugin.</b> ItemGuard will load
 *       your bridge whether or not that plugin is installed. Look it up by name at
 *       runtime, and load its classes from its own classloader. The official
 *       SmartSpawner bridge does exactly this.</li>
 *   <li><b>Be quick.</b> {@link #ownsBlock} runs on block events. Reflective lookups
 *       should be resolved once in {@link #isAvailable(PluginContext)} and cached.</li>
 *   <li><b>Return false rather than guess.</b> Saying a block is yours when it is not
 *       means ItemGuard will not let an admin find or seize it.</li>
 * </ul>
 *
 * <h2>Using it</h2>
 *
 * <pre>{@code
 * public final class MyBridge implements ItemGuardIntegration {
 *     private Method lookup;
 *     private Object api;
 *
 *     public String name() { return "MyPlugin"; }
 *
 *     public boolean isAvailable(PluginContext context) {
 *         Plugin p = context.plugin("MyPlugin");
 *         if (p == null || !p.isEnabled()) return false;
 *         try {
 *             this.api = Class.forName("com.example.api.Api", false, p.getClass().getClassLoader())
 *                 .getMethod("get").invoke(null);
 *             this.lookup = this.api.getClass().getMethod("findAt", Location.class);
 *             return true;
 *         } catch (ReflectiveOperationException e) {
 *             context.logger().warning("MyPlugin API not found: " + e);
 *             return false;
 *         }
 *     }
 *
 *     public boolean ownsBlock(Block block, Location location) {
 *         if (this.lookup == null) return false;
 *         try { return this.lookup.invoke(this.api, location) != null; }
 *         catch (ReflectiveOperationException e) { return false; }
 *     }
 * }
 * }</pre>
 *
 * @see PluginContext what a bridge is given to work with
 */
public interface ItemGuardIntegration {

    /**
     * The short name of this bridge, as it appears in {@code /ig addons}.
     *
     * <p>The one method that must be implemented. Keep it to one word with no
     * spaces: it is what an admin reads on a screen.
     *
     * @return the bridge's name, for example "SmartSpawner"
     */
    String name();

    /**
     * A friendlier name for the screen.
     *
     * @return a display name, defaulting to {@link #name()}
     */
    default String displayName() {
        return name();
    }

    /**
     * Who wrote this bridge.
     *
     * <p>Shown on the addon screen so an admin installing a community bridge can see
     * whose it is.
     *
     * @return the author, defaulting to "Unknown"
     */
    default String author() {
        return "Unknown";
    }

    /**
     * What this bridge does, in a sentence.
     *
     * @return a description, defaulting to a placeholder
     */
    default String description() {
        return "No description provided.";
    }

    /**
     * This bridge's own version, not ItemGuard's.
     *
     * @return a version string
     */
    default String version() {
        return "1.0.0";
    }

    /**
     * The material to show for this bridge on the addon screen.
     *
     * @return an icon, defaulting to paper
     */
    default Material icon() {
        return Material.PAPER;
    }

    /**
     * Free-form labels for searching or grouping, if the screen uses them.
     *
     * @return the tags, empty by default
     */
    default List<String> tags() {
        return List.of();
    }

    /**
     * The plugins that must be installed for this bridge to work.
     *
     * <p>ItemGuard checks these and reports the bridge as unavailable when one is
     * missing, which is how {@code /ig addons} explains itself rather than showing a
     * bridge that silently does nothing.
     *
     * @return plugin names, empty if none are needed
     */
    default String[] requiredPlugins() {
        return new String[0];
    }

    /**
     * Whether this bridge can work right now.
     *
     * <p>Called once at startup, and again if the bridge is reloaded. Resolve every
     * reflective lookup here and cache it: {@link #ownsBlock} runs on block events
     * and has no time to do class loading.
     *
     * <p>Return false rather than throwing if the bridged plugin is absent. That is
     * the normal case on a server without it, not an error.
     *
     * @param context what the bridge needs to look the other plugin up
     * @return true if the bridge is ready
     */
    default boolean isAvailable(PluginContext context) {
        return true;
    }

    /**
     * Whether a block belongs to the bridged plugin.
     *
     * <p>Called on block events. True means ItemGuard will treat this block as owned
     * by the other plugin: it will not let a player break it through an ItemGuard
     * command, and {@code find} will report it as belonging to the bridge rather than
     * to the item.
     *
     * <p>Return false when unsure. Saying yes about a block that is not yours means an
     * admin cannot find or seize something they are entitled to.
     *
     * @param block the block in question; never null
     * @param location where it is, for plugins that key on position
     * @return true if this block is the bridged plugin's
     */
    default boolean ownsBlock(Block block, Location location) {
        return false;
    }

    /**
     * Called when a block the bridge claimed has been removed.
     *
     * <p>The place to tell the other plugin its block is gone, if it needs telling.
     * The block is already destroyed by the time this runs, so this is a notification
     * rather than a chance to prevent anything.
     *
     * @param block the block that was removed
     * @param location where it was
     */
    default void onBlockRemoved(Block block, Location location) {
    }

    /**
     * Called when a player places a block the bridge might want to know about.
     *
     * <p>The chance to claim a block before ItemGuard has to guess. Returning an entry
     * tells ItemGuard the block is now this bridge's.
     *
     * @param player who placed it
     * @param block the block placed
     * @param placedItem the item that produced it
     * @return a map of what was claimed, empty for nothing
     */
    default Map<String, String> onBlockPlaced(Player player, Block block, ItemStack placedItem) {
        return Map.of();
    }

    /**
     * Called once the bridge has been found and {@link #isAvailable} returned true.
     *
     * <p>Schedule repeating work here if the bridge needs any. Whatever is started has
     * to stop when the bridge is unloaded; do not register your own listeners without
     * a matching cleanup, or reloading the plugin will stack them.
     *
     * @param context the same context that was passed to {@code isAvailable}
     */
    default void onEnable(PluginContext context) {
    }

    /**
     * What a bridge is given to work with, so it does not depend on ItemGuard's classes.
     *
     * <p>Passed as an argument rather than made available as a static, which is what
     * lets a bridge be compiled against nothing but this API and the bridged plugin.
     *
     * @see #isAvailable(PluginContext)
     */
    interface PluginContext {

        /**
         * Looks up an installed plugin by name.
         *
         * @param name the plugin name
         * @return the plugin, or null if it is not installed
         */
        Plugin plugin(String name);

        /**
         * Whether an installed plugin is present and enabled.
         *
         * <p>Checks the enabled state as well as the presence, because a plugin that
         * is installed but disabled has no working API.
         *
         * @param name the plugin name
         * @return true if it is installed and enabled
         */
        default boolean hasPlugin(String name) {
            Plugin found = plugin(name);
            return found != null && found.isEnabled();
        }

        /**
         * A logger to report problems on.
         *
         * <p>Prefix it with your bridge's name: the console is shared and an
         * unattributed warning is one nobody will act on.
         *
         * @return a logger to write to
         */
        Logger logger();
    }
}