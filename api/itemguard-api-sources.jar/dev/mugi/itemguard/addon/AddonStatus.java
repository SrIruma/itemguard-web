package dev.mugi.itemguard.addon;

import org.bukkit.Material;

import java.util.List;

/**
 * What {@code /ig addons} reports about one bridge.
 *
 * <p>A bridge can be inactive for reasons that are not ItemGuard's fault: the bridged
 * plugin is absent, installed but disabled, or present with an API shaped differently
 * from what the bridge expects. All of those end up here with a {@code reason},
 * because a bridge that is silently inactive is a bridge nobody can fix.
 *
 * <p>Returned by the public API so another plugin can show the same information,
 * rather than each of them scraping the console.
 *
 * @param name the bridge's own name
 * @param displayName a friendlier name for a screen
 * @param author who wrote it
 * @param description what it does
 * @param version the bridge's own version, not ItemGuard's
 * @param icon the material to show
 * @param tags free-form labels
 * @param enabled whether it hooked successfully
 * @param reason why it did not, or null when it did
 * @param requiredPlugins what must be installed for it to work
 */
public record AddonStatus(
        String name,
        String displayName,
        String author,
        String description,
        String version,
        Material icon,
        List<String> tags,
        boolean enabled,
        String reason,
        String[] requiredPlugins) {
}